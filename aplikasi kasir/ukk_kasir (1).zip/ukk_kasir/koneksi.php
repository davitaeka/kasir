<?php 
$koneksi = mysqli_connect("localhost","davitaeka","210805","kasir1");

// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}

?>